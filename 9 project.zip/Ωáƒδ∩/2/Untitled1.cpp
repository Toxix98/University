#include <iostream>
#include <math.h>
using namespace std;

void rishe(float a, float b, float c);

int main()
{
    float a, b, c;
    cout << "Please enter a, b, c: ";
    cin >> a >> b >> c;
    rishe(a, b, c);
    return 0;
}

void rishe(float a, float b, float c)
{
    float x, y, del;
    del = b * b - 4 * a * c;
    if (del < 0)
    {
        cout << "rishe nadarad";
    }
    else
    {
        x = (-b + sqrt(del)) / (2 * a);
        y = (-b - sqrt(del)) / (2 * a);
        cout << "x1 = " << x << ", x2 = " << y;
    }
}