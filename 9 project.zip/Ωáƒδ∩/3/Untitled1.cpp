#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	float a, b, c, mohit, masahat, s;
	cout <<"Pleas enter your numbers:";
	cin >>a>>b>>c;
	mohit = a + b + c;
	s = (a + b + c)/2;
	masahat = sqrtl(s*(s - a)*(s - b)*(s - c));
	printf("masahat is : %2.f\n", masahat);
	printf("mohit is : %2.f\n", mohit);
	
	return 0;
}