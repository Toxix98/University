#include <iostream>
using namespace std;

int main()
{
	int A, N, Q;
	cout <<"Pleas Enter your numbers \n :";
	cin >>A>>N>>Q;
	if((A < N + Q) && (N < A + Q) && (Q < A + N))
	{
		cout <<"mitavanad moslas bashad";
	}
	else
	{
		cout <<"nemitavanad moslas bashad";
	}
}