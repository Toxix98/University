#include <iostream>
#include <math.h>
#include <conio.h>
#include <stdlib.h>

using namespace std;

int main()
{
    float r, h, result1, result2;
    cout << "Please Enter Your Number1 :";
    cin >> r;
    cout << "Please Enter Your Number2 :";
    cin >> h;
    result1 = 2 * 3.14 * (h + r);
    result2 = (2 * 3.14 * r) * r;
    printf("masahat is : %.2f\n", result1);
    printf("mohit is : %.2f\n", result2);
    return 0;
}