#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	float a, n, q, an;
	cout << "Enter your numbers :";
	cin >>a>>n>>q;
	
	an 	= a * pow(q, n-1);
	
	cout << "The " << n << "th term of the geometric progression with first term " << a << " and common ratio " << q << " is " << an;
}