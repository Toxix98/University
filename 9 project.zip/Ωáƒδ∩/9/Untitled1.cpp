#include <iostream>
using namespace std;

int main()
{
    int count = 0;
    int students_68_69 = 0;
    int students_71 = 0;
    int other_years = 0;
    int year;
    do {
        cout << "Enter a two-digit positive integer (or 99 to exit): ";
        cin >> year;
        if (year >= 10 && year <= 99) {
            count++;
            if (year == 68 || year == 69) {
                cout << "Enter the number of students who entered in " << year << ": ";
                cin >> students_68_69;
            } else if (year == 71) {
                cout << "Enter the number of students who entered in " << year << ": ";
                cin >> students_71;
            } else {
                other_years++;
            }
        }
    } while (year != 99);
    cout << "Number of positive two-digit integers entered: " << count << endl;
    cout << "Number of students who entered in 68 and 69: " << students_68_69 << endl;
    cout << "Number of students who entered in 71: " << students_71 << endl;
    cout << "Number of students who entered in other years: " << other_years << endl;
    return 0;
}