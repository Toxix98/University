#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int n, k;
	cin >>n>>k;
	for(int i = 1; i <= k; i++)
	{
		n = n * i;	 
		cout <<n<< "\n";
	}
	cout << n;
}